**About This Project**

This code is designed with the purpose of displaying information about a user when their name is searched. While there is a lot more that can be added and improved in this project, I’ve currently built only this part for the purpose of learning and practice.

During the development of this project, I faced several challenges. However, I was able to overcome them with the help of resources like Google, MDN Docs, and W3Schools. Finally, I managed to complete it successfully.

This is essentially a part of my learning journey. I’ve tried my best to keep the code clean and professional. I also attempted to make the design look decent, though my main focus in this project was JavaScript functionality.

The API used here is a fake API, which I’ve used purely for testing purposes.

Thank you for taking the time to read a bit about my project.

